import unittest
from app import app

class TestApp(unittest.TestCase):

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_index_page(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)

    def test_search_with_valid_query(self):
        response = self.app.post('/', data=dict(query='test query', top_k=5))
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Search Results', response.data)

    def test_search_with_invalid_query(self):
        response = self.app.post('/', data=dict(query='', top_k=5))
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Enter your query', response.data)

if __name__ == '__main__':
    unittest.main()
