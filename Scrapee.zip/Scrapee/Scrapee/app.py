import os
import pickle

from flask import Flask, jsonify, render_template, request
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Initialize Flask app
app = Flask(__name__)

# Load TF-IDF vectorizer and cosine similarity matrix
with open("tfidf_vectorizer.pickle", "rb") as handle:
    vectorizer = pickle.load(handle)

with open("cosine_similarity_matrix.pickle", "rb") as handle:
    cosine_sim_matrix = pickle.load(handle)

# Path to the folder containing HTML documents
documents_folder = "output"

# Function to load documents from the folder
def load_documents(folder_path):
    documents = []
    filenames = os.listdir(folder_path)
    for filename in filenames:
        with open(os.path.join(folder_path, filename), "r", encoding="utf-8") as file:
            document = file.read()
            documents.append(document)
    return documents

# Load documents
documents = load_documents(documents_folder)

def get_url_for_filename(filename):
    # Remove the 'quotes-' prefix and '.html' suffix to get the page name
    page_name = filename.replace('quotes-', '').replace('.html', '')
    
    # Define a dictionary to map each page name to its corresponding URL
    page_urls = {
        "forms": "https://www.scrapethissite.com/pages/forms/",
        "frames": "https://www.scrapethissite.com/pages/frames/",
        "simple": "https://www.scrapethissite.com/pages/simple/",
        "ajax-javascript": "https://www.scrapethissite.com/pages/ajax-javascript/",
        "advanced": "https://www.scrapethissite.com/pages/advanced/"
    }

    # Return the URL corresponding to the page name
    return page_urls.get(page_name, "")

# Route for rendering index.html and processing queries
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        return render_template('index.html')
    elif request.method == 'POST':
        query = request.form['query']
        top_k = int(request.form.get('top_k', 5))

        # Vectorize query
        query_vector = vectorizer.transform([query])

        # Calculate cosine similarity between query and documents
        cosine_similarities = cosine_similarity(query_vector, vectorizer.transform(documents))

        # Get top-K similar documents
        top_indices = cosine_similarities.argsort()[0][-top_k:][::-1]

        # Construct response
        results = []
        for idx in top_indices:
            filename = os.listdir(documents_folder)[idx]
            url = get_url_for_filename(filename)  # You need to define a function to get the URL for the filename
            results.append({
                'filename': filename,
                'url': url,
                'cosine_similarity': cosine_sim_matrix[idx][0]
            })

        return render_template('index.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
