from pathlib import Path

import scrapy


class ProjectSpider(scrapy.Spider):
    name = "project"
    # Initialize seed URL, max pages, and max depth
    def __init__(self, *args, **kwargs):
        super(ProjectSpider, self).__init__(*args, **kwargs)
        self.seed_url = kwargs.get('seed_url', "https://scrapethissite.com")
        self.max_pages = kwargs.get('max_pages', 10)
        self.max_depth = kwargs.get('max_depth', 3)

    def start_requests(self):
        urls = [
            "https://www.scrapethissite.com/pages/simple/",
            "https://www.scrapethissite.com/pages/forms/",
            "https://www.scrapethissite.com/pages/frames/",
            "https://www.scrapethissite.com/pages/ajax-javascript/",
            "https://www.scrapethissite.com/pages/advanced/",
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse,  meta={'depth': 0})

    # Parse response
    def parse(self, response):
        # Save HTML content
        page = response.url.split("/")[-2]
        filename = f"quotes-{page}.html"
        Path(filename).write_bytes(response.body)
        self.log(f"Saved file {filename}")

        # Extract links and follow recursively up to max depth
        if response.meta['depth'] < self.max_depth:
            links = response.css('a::attr(href)').extract()
            for link in links:
                yield response.follow(link, callback=self.parse, meta={'depth': response.meta['depth'] + 1})

        # Control max pages
        if self.max_pages > 0:
            self.max_pages -= 1
            if self.max_pages == 0:
                self.crawler.engine.close_spider(self, 'Reached max pages limit')

    # Optional: Implement AutoThrottle for concurrent crawling
    custom_settings = {
        'AUTOTHROTTLE_ENABLED': True,
        'AUTOTHROTTLE_TARGET_CONCURRENCY': 0.5,
    }